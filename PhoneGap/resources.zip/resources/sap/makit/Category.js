/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.makit.Category");jQuery.sap.require("sap.makit.library");jQuery.sap.require("sap.ui.core.Element");sap.ui.core.Element.extend("sap.makit.Category",{metadata:{library:"sap.makit",properties:{"column":{type:"string",group:"Misc",defaultValue:null},"displayName":{type:"string",group:"Misc",defaultValue:null},"format":{type:"string",group:"Misc",defaultValue:null}}}});
/*!
 * @copyright@
 */

/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.makit.Series");jQuery.sap.require("sap.makit.library");jQuery.sap.require("sap.ui.core.Element");sap.ui.core.Element.extend("sap.makit.Series",{metadata:{library:"sap.makit",properties:{"column":{type:"string",group:"Data",defaultValue:null},"displayName":{type:"string",group:"Appearance",defaultValue:null},"format":{type:"string",group:"Misc",defaultValue:null}}}});
/*!
 * @copyright@
 */

/**
 * @copyright
 */
jQuery.sap.declare("sap.m.FacetFilterListRenderer");sap.m.FacetFilterListRenderer={};
sap.m.FacetFilterListRenderer.render=function(r,c){};
